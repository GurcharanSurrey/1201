// NOTE: You may, but do not have to, modify this file, such as to create other
// classes or to call methods on `App`. You may not add any global state
// variables.
const app = new App(new MenuScreen(document.getElementById("menu")), new MusicScreen(document.getElementById("music")));

