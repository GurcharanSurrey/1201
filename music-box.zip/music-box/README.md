# HW4: Music Box

This is the starter code for HW4: Music Box. Please [check out the spec](http://cs193x.stanford.edu/homework/4-musicbox) for an explanation of the starter files.
